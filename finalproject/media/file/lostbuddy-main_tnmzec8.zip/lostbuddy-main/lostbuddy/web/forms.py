from django import forms
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import get_user_model
from .constants import PROVINCE_CHOICES

from .models import Post, PostImage, PostType, PetGender, PetSize, PostStatus


class PostForm(forms.ModelForm):
    province = forms.ChoiceField(choices=PROVINCE_CHOICES, required=False, label="จังหวัด")
    class Meta:
        model = Post
        fields = [
            "type",
            "status",
            "description",
            "pet_type",
            "breed",
            "color",
            "gender",
            "size",
            "distinguishing_features",
            "collar_details",
            "event_date",
            "latitude",
            "longitude",
            "address_text",
            "district",
            "province",
            "contact_name",
            "contact_phone",
            "contact_line",
        ]
        widgets = {
            "description": forms.Textarea(attrs={"rows": 3}),
            "distinguishing_features": forms.Textarea(attrs={"rows": 2}),
            "collar_details": forms.Textarea(attrs={"rows": 2}),
            "event_date": forms.DateTimeInput(attrs={"type": "datetime-local"}),
        }

    def clean(self):
        cleaned = super().clean()
        lat = cleaned.get("latitude")
        lng = cleaned.get("longitude")
        if lat is not None and (lat < -90 or lat > 90):
            self.add_error("latitude", "ละติจูดต้องอยู่ระหว่าง -90 ถึง 90")
        if lng is not None and (lng < -180 or lng > 180):
            self.add_error("longitude", "ลองจิจูดต้องอยู่ระหว่าง -180 ถึง 180")
        return cleaned


class PostImageForm(forms.ModelForm):
    class Meta:
        model = PostImage
        fields = ["image"]
        widgets = {
            # Use plain FileInput to hide Django's default "Clear" checkbox
            "image": forms.FileInput(),
        }


PostImageFormSet = inlineformset_factory(
    Post, PostImage, form=PostImageForm, extra=3, can_delete=True
)

class SignupForm(UserCreationForm):
    full_name = forms.CharField(max_length=255, required=False, label="ชื่อ-นามสกุล")
    email = forms.EmailField(required=False, label="อีเมล")
    phone_number = forms.CharField(max_length=50, required=False, label="เบอร์โทร")
    line_id = forms.CharField(max_length=100, required=False, label="Line ID")

    class Meta(UserCreationForm.Meta):
        model = get_user_model()
        fields = ("username", "password1", "password2", "email", "full_name", "phone_number", "line_id")

    def save(self, commit=True):
        user = super().save(commit=False)
        # Persist email if provided
        email = self.cleaned_data.get("email")
        if email:
            user.email = email
        if commit:
            user.save()
        # Ensure profile exists (signal also creates, but update values here)
        profile = getattr(user, "profile", None)
        if profile is None:
            from .models import Profile
            profile = Profile.objects.create(user=user)
        profile.full_name = self.cleaned_data.get("full_name") or ""
        profile.phone_number = self.cleaned_data.get("phone_number") or ""
        profile.line_id = self.cleaned_data.get("line_id") or ""
        if commit:
            profile.save()
        return user
