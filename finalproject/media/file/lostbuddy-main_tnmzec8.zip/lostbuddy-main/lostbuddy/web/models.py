from django.conf import settings
from django.db import models
from django.contrib.auth import get_user_model
from django.db.models.signals import post_save
from django.dispatch import receiver


class PostType(models.TextChoices):
    LOST = "LOST", "LOST"
    FOUND = "FOUND", "FOUND"


class PetGender(models.TextChoices):
    MALE = "MALE", "MALE"
    FEMALE = "FEMALE", "FEMALE"
    UNKNOWN = "UNKNOWN", "UNKNOWN"


class PetSize(models.TextChoices):
    SMALL = "SMALL", "SMALL"
    MEDIUM = "MEDIUM", "MEDIUM"
    LARGE = "LARGE", "LARGE"


class PostStatus(models.TextChoices):
    ACTIVE = "ACTIVE", "ACTIVE"
    REUNITED = "REUNITED", "REUNITED"
    CLOSED = "CLOSED", "CLOSED"


class Post(models.Model):
    # ผู้สร้างโพสต์ (allow null to emulate ON DELETE SET NULL)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="posts",
    )

    # Post Details
    type = models.CharField(max_length=10, choices=PostType.choices)
    status = models.CharField(max_length=10, choices=PostStatus.choices, default=PostStatus.ACTIVE)
    description = models.TextField(blank=True)

    # Pet Details
    pet_type = models.CharField(max_length=100)  # e.g., สุนัข/แมว
    breed = models.CharField(max_length=100, blank=True)
    color = models.CharField(max_length=100, blank=True)
    gender = models.CharField(max_length=10, choices=PetGender.choices, default=PetGender.UNKNOWN)
    size = models.CharField(max_length=10, choices=PetSize.choices, blank=True)
    distinguishing_features = models.TextField(blank=True)
    collar_details = models.TextField(blank=True)

    # Location & Time
    event_date = models.DateTimeField(null=True, blank=True)
    # Non-spatial fallback (no GDAL required)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    address_text = models.CharField(max_length=255, blank=True)
    district = models.CharField(max_length=100, blank=True)
    province = models.CharField(max_length=100, blank=True)

    # Contact (may differ from profile)
    contact_name = models.CharField(max_length=255, blank=True)
    contact_phone = models.CharField(max_length=50, blank=True)
    contact_line = models.CharField(max_length=100, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        indexes = [
            models.Index(fields=["user"], name="idx_posts_user_id"),
            models.Index(fields=["type", "status"], name="idx_posts_type_status"),
            models.Index(fields=["pet_type"], name="idx_posts_pet_type"),
        ]

    def __str__(self) -> str:
        return f"{self.type} {self.pet_type} - {self.province or ''}"

    def get_absolute_url(self):
        from django.urls import reverse
        return reverse("web:post_detail", kwargs={"pk": self.pk})


class PostImage(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name="images")
    image = models.ImageField(upload_to="post_images/", null=True, blank=True)
    image_url = models.URLField(blank=True)
    display_order = models.SmallIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [
            models.Index(fields=["post"], name="idx_post_images_post_id"),
        ]
        ordering = ["display_order", "id"]

    def __str__(self) -> str:
        return f"Image #{self.pk} for Post #{self.post_id}"


class Profile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="profile")
    full_name = models.CharField(max_length=255, blank=True)
    phone_number = models.CharField(max_length=50, blank=True)
    line_id = models.CharField(max_length=100, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self) -> str:
        return f"Profile({self.user})"


@receiver(post_save, sender=get_user_model())
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)
