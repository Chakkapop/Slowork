from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="Post",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("type", models.CharField(choices=[("LOST", "LOST"), ("FOUND", "FOUND")], max_length=10)),
                ("status", models.CharField(choices=[("ACTIVE", "ACTIVE"), ("REUNITED", "REUNITED"), ("CLOSED", "CLOSED")], default="ACTIVE", max_length=10)),
                ("description", models.TextField(blank=True)),
                ("pet_type", models.CharField(max_length=100)),
                ("breed", models.CharField(blank=True, max_length=100)),
                ("color", models.CharField(blank=True, max_length=100)),
                ("gender", models.CharField(choices=[("MALE", "MALE"), ("FEMALE", "FEMALE"), ("UNKNOWN", "UNKNOWN")], default="UNKNOWN", max_length=10)),
                ("size", models.CharField(blank=True, choices=[("SMALL", "SMALL"), ("MEDIUM", "MEDIUM"), ("LARGE", "LARGE")], max_length=10)),
                ("distinguishing_features", models.TextField(blank=True)),
                ("collar_details", models.TextField(blank=True)),
                ("event_date", models.DateTimeField(blank=True, null=True)),
                ("latitude", models.FloatField(blank=True, null=True)),
                ("longitude", models.FloatField(blank=True, null=True)),
                ("address_text", models.CharField(blank=True, max_length=255)),
                ("district", models.CharField(blank=True, max_length=100)),
                ("province", models.CharField(blank=True, max_length=100)),
                ("contact_name", models.CharField(blank=True, max_length=255)),
                ("contact_phone", models.CharField(blank=True, max_length=50)),
                ("contact_line", models.CharField(blank=True, max_length=100)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("user", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="posts", to=settings.AUTH_USER_MODEL)),
            ],
            options={
                "indexes": [
                    models.Index(fields=["user"], name="idx_posts_user_id"),
                    models.Index(fields=["type", "status"], name="idx_posts_type_status"),
                    models.Index(fields=["pet_type"], name="idx_posts_pet_type"),
                ],
            },
        ),
        migrations.CreateModel(
            name="PostImage",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("image_url", models.URLField()),
                ("display_order", models.SmallIntegerField(default=0)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("post", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="images", to="web.post")),
            ],
            options={
                "ordering": ["display_order", "id"],
                "indexes": [models.Index(fields=["post"], name="idx_post_images_post_id")],
            },
        ),
    ]
