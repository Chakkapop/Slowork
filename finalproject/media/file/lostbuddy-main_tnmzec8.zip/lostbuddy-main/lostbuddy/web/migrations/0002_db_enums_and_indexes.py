from django.db import migrations


CREATE_ENUMS = r"""
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'post_type') THEN
        CREATE TYPE post_type AS ENUM ('LOST', 'FOUND');
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'pet_gender') THEN
        CREATE TYPE pet_gender AS ENUM ('MALE', 'FEMALE', 'UNKNOWN');
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'pet_size') THEN
        CREATE TYPE pet_size AS ENUM ('SMALL', 'MEDIUM', 'LARGE');
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'post_status') THEN
        CREATE TYPE post_status AS ENUM ('ACTIVE', 'REUNITED', 'CLOSED');
    END IF;
END$$;
"""


ALTER_TO_ENUMS = r"""
ALTER TABLE web_post
    ALTER COLUMN type TYPE post_type USING type::post_type,
    ALTER COLUMN status TYPE post_status USING status::post_status,
    ALTER COLUMN gender TYPE pet_gender USING gender::pet_gender;

-- size column can be NULL/blank; cast carefully
ALTER TABLE web_post
    ALTER COLUMN size TYPE pet_size USING NULLIF(size, '')::pet_size;
"""


REVERT_FROM_ENUMS = r"""
ALTER TABLE web_post
    ALTER COLUMN type TYPE varchar(10) USING type::text,
    ALTER COLUMN status TYPE varchar(10) USING status::text,
    ALTER COLUMN gender TYPE varchar(10) USING gender::text,
    ALTER COLUMN size TYPE varchar(10) USING size::text;
"""


DROP_ENUMS = r"""
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_type WHERE typname = 'post_type') THEN
        DROP TYPE post_type;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_type WHERE typname = 'pet_gender') THEN
        DROP TYPE pet_gender;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_type WHERE typname = 'pet_size') THEN
        DROP TYPE pet_size;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_type WHERE typname = 'post_status') THEN
        DROP TYPE post_status;
    END IF;
END$$;
"""


CREATE_COORD_INDEXES = r"""
CREATE INDEX IF NOT EXISTS idx_posts_latitude ON web_post (latitude);
CREATE INDEX IF NOT EXISTS idx_posts_longitude ON web_post (longitude);
"""


class Migration(migrations.Migration):

    dependencies = [
        ('web', '0001_initial'),
    ]

    operations = [
        migrations.RunSQL(sql=CREATE_ENUMS, reverse_sql=DROP_ENUMS),
        migrations.RunSQL(sql=ALTER_TO_ENUMS, reverse_sql=REVERT_FROM_ENUMS),
        migrations.RunSQL(sql=CREATE_COORD_INDEXES, reverse_sql="""
            DROP INDEX IF EXISTS idx_posts_latitude;
            DROP INDEX IF EXISTS idx_posts_longitude;
        """),
    ]
