from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('web', '0002_db_enums_and_indexes'),
    ]

    operations = [
        migrations.AddField(
            model_name='postimage',
            name='image',
            field=models.ImageField(blank=True, null=True, upload_to='post_images/'),
        ),
        migrations.AlterField(
            model_name='postimage',
            name='image_url',
            field=models.URLField(blank=True),
        ),
    ]

