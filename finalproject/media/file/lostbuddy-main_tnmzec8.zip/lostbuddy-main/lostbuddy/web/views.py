from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login
from django.core.paginator import Paginator
from django.db.models import Q
from django.http import Http404, HttpResponseForbidden
from django.shortcuts import get_object_or_404, redirect, render

from .models import Post, PostImage, PostStatus
from django.db.models import F, FloatField, Value
from django.db.models.functions import ACos, ASin, Cos, Radians, Sin, Sqrt, Power
from .forms import PostForm, PostImageFormSet, SignupForm
from .constants import PROVINCE_CHOICES


def post_list(request):
    qs = Post.objects.all().order_by("-created_at")

    post_type = request.GET.get("type")
    pet_type = request.GET.get("pet_type")
    province = request.GET.get("province")
    gender = request.GET.get("gender")
    size = request.GET.get("size")
    status = request.GET.get("status")
    q = request.GET.get("q")
    date_from = request.GET.get("date_from")
    date_to = request.GET.get("date_to")

    if post_type:
        qs = qs.filter(type=post_type)
    if pet_type:
        qs = qs.filter(pet_type__icontains=pet_type)
    if province:
        qs = qs.filter(province__icontains=province)
    if gender:
        qs = qs.filter(gender=gender)
    if size:
        qs = qs.filter(size=size)
    if status:
        qs = qs.filter(status=status)
    if q:
        qs = qs.filter(
            Q(description__icontains=q)
            | Q(breed__icontains=q)
            | Q(color__icontains=q)
            | Q(district__icontains=q)
            | Q(province__icontains=q)
        )
    if date_from:
        qs = qs.filter(event_date__date__gte=date_from)
    if date_to:
        qs = qs.filter(event_date__date__lte=date_to)

    # Radius search (Haversine) if params provided
    center_lat = request.GET.get("lat")
    center_lng = request.GET.get("lng")
    radius_km = request.GET.get("radius") or request.GET.get("radius_km")
    if center_lat and center_lng and radius_km:
        try:
            lat0 = float(center_lat)
            lng0 = float(center_lng)
            rkm = float(radius_km)
            # Haversine distance in km
            dlat = Radians(F("latitude") - Value(lat0))
            dlng = Radians(F("longitude") - Value(lng0))
            a = Power(Sin(dlat / 2.0), 2) + Cos(Radians(Value(lat0))) * Cos(Radians(F("latitude"))) * Power(Sin(dlng / 2.0), 2)
            c = 2.0 * ASin(Sqrt(a))
            distance_km = 6371.0088 * c
            qs = qs.filter(latitude__isnull=False, longitude__isnull=False).annotate(distance_km=distance_km).filter(distance_km__lte=rkm).order_by("distance_km", "-created_at")
        except ValueError:
            pass

    paginator = Paginator(qs, 12)
    page_obj = paginator.get_page(request.GET.get("page"))
    ctx = {
        "page_obj": page_obj,
        "filters": {
            "type": post_type,
            "pet_type": pet_type,
            "province": province,
            "gender": gender,
            "size": size,
            "status": status,
            "q": q,
            "date_from": date_from,
            "date_to": date_to,
            "lat": center_lat,
            "lng": center_lng,
            "radius": radius_km,
        },
        "province_choices": PROVINCE_CHOICES,
    }
    return render(request, "web/post_list.html", ctx)


def post_detail(request, pk: int):
    post = get_object_or_404(Post, pk=pk)
    return render(request, "web/post_detail.html", {"post": post})


@login_required
def post_create(request):
    if request.method == "POST":
        form = PostForm(request.POST)
        formset = PostImageFormSet(request.POST, request.FILES, prefix="img")
        if form.is_valid() and formset.is_valid():
            obj = form.save(commit=False)
            obj.user = request.user
            obj.save()
            formset.instance = obj
            formset.save()
            messages.success(request, "สร้างประกาศเรียบร้อย")
            return redirect("web:post_detail", pk=obj.pk)
    else:
        form = PostForm()
        formset = PostImageFormSet(prefix="img")
    return render(request, "web/post_form.html", {"form": form, "formset": formset})


@login_required
def post_edit(request, pk: int):
    obj = get_object_or_404(Post, pk=pk)
    if obj.user_id and obj.user_id != request.user.id:
        return HttpResponseForbidden("คุณไม่มีสิทธิ์แก้ไขประกาศนี้")
    if request.method == "POST":
        form = PostForm(request.POST, instance=obj)
        formset = PostImageFormSet(request.POST, request.FILES, instance=obj, prefix="img")
        if form.is_valid() and formset.is_valid():
            form.save()
            formset.save()
            messages.success(request, "แก้ไขประกาศเรียบร้อย")
            return redirect("web:post_detail", pk=obj.pk)
    else:
        form = PostForm(instance=obj)
        formset = PostImageFormSet(instance=obj, prefix="img")
    return render(request, "web/post_form.html", {"form": form, "formset": formset, "object": obj})


@login_required
def post_delete(request, pk: int):
    obj = get_object_or_404(Post, pk=pk)
    if obj.user_id and obj.user_id != request.user.id:
        # Allow admins/superusers or users with delete permission to delete others' posts
        if not (request.user.is_superuser or request.user.has_perm("web.delete_post")):
            return HttpResponseForbidden("คุณไม่มีสิทธิ์ลบประกาศนี้")
    if request.method == "POST":
        obj.delete()
        messages.success(request, "ลบประกาศเรียบร้อย")
        return redirect("web:post_list")
    return render(request, "web/post_confirm_delete.html", {"object": obj})


@login_required
def post_change_status(request, pk: int):
    obj = get_object_or_404(Post, pk=pk)
    if obj.user_id and obj.user_id != request.user.id:
        return HttpResponseForbidden("คุณไม่มีสิทธิ์เปลี่ยนสถานะประกาศนี้")
    value = request.GET.get("value")
    if value not in (PostStatus.ACTIVE, PostStatus.REUNITED, PostStatus.CLOSED):
        raise Http404("สถานะไม่ถูกต้อง")
    obj.status = value
    obj.save(update_fields=["status", "updated_at"])
    messages.success(request, "อัปเดตสถานะเรียบร้อย")
    return redirect("web:post_detail", pk=obj.pk)


@login_required
def my_posts(request):
    qs = Post.objects.filter(user=request.user).order_by("-created_at")
    paginator = Paginator(qs, 20)
    page_obj = paginator.get_page(request.GET.get("page"))
    return render(request, "web/my_posts.html", {"page_obj": page_obj})


def signup(request):
    if request.method == "POST":
        form = SignupForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "สมัครสมาชิกเรียบร้อย")
            return redirect("web:post_list")
    else:
        form = SignupForm()
    return render(request, "registration/signup.html", {"form": form})
