from django.contrib import admin
from .models import Post, PostImage, Profile


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "type",
        "status",
        "pet_type",
        "province",
        "event_date",
        "user",
        "created_at",
    )
    list_filter = ("type", "status", "pet_type", "province")
    search_fields = ("description", "pet_type", "breed", "color", "province", "district")


@admin.register(PostImage)
class PostImageAdmin(admin.ModelAdmin):
    list_display = ("id", "post", "display_order", "created_at")
    list_filter = ("display_order",)


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "full_name", "phone_number", "line_id", "created_at")
    search_fields = ("user__username", "full_name", "phone_number", "line_id")
