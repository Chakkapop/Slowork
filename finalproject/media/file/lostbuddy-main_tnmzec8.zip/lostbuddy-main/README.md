# Lost Buddy (โหมดไม่ใช้ GeoDjango)

Lost Buddy คือเว็บแอปช่วยตามหาสัตว์เลี้ยงที่หาย และประกาศสัตว์เลี้ยงที่พบ ในโปรเจกต์นี้ตั้งค่าให้ทำงานได้โดย “ไม่ต้องติดตั้ง GDAL/GeoDjango” โดยใช้ฟิลด์ละติจูด/ลองจิจูด และค้นหารัศมีด้วยสูตร Haversine แทน PostGIS

## สิ่งที่ต้องมี

- Python 3.12 (แนะนำ 64‑bit)
- PostgreSQL (โหมดนี้ไม่ต้องใช้ PostGIS)
- pip และ Virtual Environment (แนะนำ)

## ติดตั้งแบบรวดเร็ว

1) สร้างและเปิดใช้งาน virtualenv

```
python -m venv .venv
. .venv/Scripts/activate  # บน PowerShell: .venv\Scripts\Activate.ps1
```

2) ติดตั้งแพ็กเกจ

```
pip install -U pip
pip install -r requirements.txt
```

3) ตั้งค่า Database

แก้ไฟล์ `lostbuddy/lostbuddy/lostbuddy/settings.py` ที่ `DATABASES['default']` ให้ตรงกับ PostgreSQL ของคุณ แล้วสร้างฐานข้อมูลเปล่า เช่น:

```
CREATE DATABASE lostbuddy;
```

4) migrate และสร้างผู้ดูแลระบบ

```
cd lostbuddy/lostbuddy
python manage.py migrate
python manage.py createsuperuser
```

5) รันเซิร์ฟเวอร์พัฒนา

```
python manage.py runserver
```

- หน้าเว็บหลัก: http://127.0.0.1:8000/
- แอดมิน: http://127.0.0.1:8000/admin/

## ฟีเจอร์หลัก

- โพสต์ประกาศแบบ LOST/FOUND พร้อมรายละเอียด: ประเภทสัตว์ สายพันธุ์ สี เพศ ขนาด ข้อความสถานที่ เวลาที่พบ/หาย ข้อมูลติดต่อ
- แนบรูปภาพหลายรูป (อัปโหลดไฟล์จริง) โดยไม่ต้องใส่ URL
- ค้นหาและฟิลเตอร์ตามประเภท/สัตว์/จังหวัด/เพศ/ขนาด/ช่วงวันที่/คำค้น
- ค้นหาตามรัศมีด้วยสูตร Haversine (ไม่ใช้ PostGIS): ส่ง `lat`, `lng`, `radius` (กม.)
  - ตัวอย่าง: `/?lat=13.736&lng=100.523&radius=5`
- ระบบผู้ใช้: สมัครสมาชิก, เข้าสู่ระบบ, ดู “ประกาศของฉัน”
- สิทธิ์แอดมิน: ลบโพสต์ของผู้อื่นได้ (superuser หรือมีสิทธิ์ `web.delete_post`)

## อัปโหลดไฟล์รูป

- โหมด DEBUG เสิร์ฟไฟล์สื่อผ่าน:
  - `MEDIA_URL = /media/`
  - `MEDIA_ROOT = <repo>/lostbuddy/lostbuddy/media`
- ให้สิทธิ์เขียนโฟลเดอร์ `MEDIA_ROOT` แก่แอปพลิเคชัน

## คำสั่งที่ใช้บ่อย

```
# จากโฟลเดอร์รูทของรีโป
pip install -r requirements.txt

# จากโฟลเดอร์ที่มี manage.py
cd lostbuddy/lostbuddy
python manage.py migrate
python manage.py runserver
```

## หมายเหตุ

- `psycopg2-binary` เหมาะกับงานพัฒนา สำหรับโปรดักชันแนะนำ `psycopg2` ที่คอมไพล์กับไลบรารีระบบ
- โปรดตั้ง `DEBUG=False` และกำหนด `ALLOWED_HOSTS` ให้เหมาะสมเมื่อขึ้นโปรดักชัน

## แก้ปัญหาทั่วไป

- สมัครแล้วไม่เห็นข้อมูล: ตรวจว่า migrate แล้ว และดูข้อความ error ใต้ช่องกรอกในหน้าสมัคร
